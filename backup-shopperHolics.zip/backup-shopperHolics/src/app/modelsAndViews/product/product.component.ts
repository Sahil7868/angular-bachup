import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../controllers/product.service';
import { HeaderComponent } from '../header/header.component'
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {


  faci: number;
  cart = { pid: 0, email: 'sahilsurani7868@gmail.com', total: 0 };
  products: any = [];
  slides: any = [[]];
  qauntityArray: any = [];
  constructor(public rest: ProductService) { }

  chunk(arr, chunkSize) {
    let R = [];
    //console.log(arr);
    for (let i = 0, len = arr.length; i < len; i += chunkSize) {
      R.push(arr.slice(i, i + chunkSize));
    }
    return R;
  }

  ngOnInit() {
    this.getProduct();


  }

  getProduct() {
    this.products = [];
    this.rest.getProduct().subscribe((data: {}) => {
      // console.log(data);
      this.products = data;
      this.slides = this.chunk(this.products, 3);
    });

  }
  createRange(number) {
    this.qauntityArray = [];
    for (var i = 1; i <= number; i++) {
      this.qauntityArray.push(i);
    }
    return this.qauntityArray;
  }

  addTocart(pid, price) {
    if (this.faci == 0) {
      alert("Select appropriate Qauntity");
    }
    else {
      this.cart.pid = pid;
      this.cart.total = (this.faci * price);
      console.log(pid);
      console.log(this.cart.total);
      this.rest.addToCart(this.cart).subscribe((result) => {
        console.log(result);
        alert("Added Successfully");
      }, (err) => {
        console.log(err);
      });


    }
  }

}

