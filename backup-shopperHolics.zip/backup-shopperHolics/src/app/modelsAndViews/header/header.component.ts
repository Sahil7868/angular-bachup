import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../../controllers/category.service';
import { ProductService } from '../../controllers/product.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

// https://community.algolia.com/angular-instantsearch/getting-started.html
export class HeaderComponent implements OnInit {

  products:any = [];
  carts:any=[];
  constructor(public rest:CategoryService, public _pro:ProductService ) { }

  ngOnInit() {
    this.getCategory();
    this.getCart();
}

getCategory() {
  this.products = [];
  this.rest.getCategory().subscribe((data: {}) => {
   // console.log(data);
    this.products = data;
  });
}

getCart() {
  this.carts = [];
  this._pro.getCart('sahilsurani7868@gmail.com').subscribe((data: {}) => {
   // console.log(data);
    this.carts = data;
    
  });

}

}
