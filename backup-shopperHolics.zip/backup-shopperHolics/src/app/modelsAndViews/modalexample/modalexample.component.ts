import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modalexample',
  templateUrl: './modalexample.component.html',
  styleUrls: ['./modalexample.component.scss']
})
export class ModalexampleComponent implements OnInit {

  colorSelect: Array<any>;
  sizeSelect: Array<any>;

  public itemsList: Object[] = [
    {
    title: 'Description',
    description: 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson'
    
    },
    {
    title: 'Details',
    description: 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson'
    },
    {
    title: 'Shipping',
    description: 'Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson'
    }
    ];


  constructor() { }
 
  ngOnInit() {
    this.colorSelect = [
    { value: 'Black', label: 'Black' },
    { value: 'White', label: 'White' },
    { value: 'Red', label: 'Red' },
    ];
    this.sizeSelect = [
    { value: 'XS', label: 'XS' },
    { value: 'S', label: 'S' },
    { value: 'L', label: 'L' },
    ];
    }
 

}
