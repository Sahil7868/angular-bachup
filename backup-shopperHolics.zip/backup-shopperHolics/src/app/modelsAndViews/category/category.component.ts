import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../../controllers/category.service';
//import { Router } from '@angular/router';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit {

  products:any = [];
  constructor(public rest:CategoryService) { }

  ngOnInit() {
      this.getCategory();
  }

  getCategory() {
    this.products = [];
    this.rest.getCategory().subscribe((data: {}) => {
     // console.log(data);
      this.products = data;
    });
  }

}
