import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-bootstrap-module',
  templateUrl: './app-bootstrap-module.component.html',
  styleUrls: ['./app-bootstrap-module.component.css']
})
export class AppBootstrapModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
