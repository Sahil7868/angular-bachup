import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppBootstrapModuleComponent } from './app-bootstrap-module.component';

describe('AppBootstrapModuleComponent', () => {
  let component: AppBootstrapModuleComponent;
  let fixture: ComponentFixture<AppBootstrapModuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppBootstrapModuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppBootstrapModuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
