import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppBoostrapModuleModule } from './app-boostrap-module/app-boostrap-module.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppBootstrapModuleComponent } from './NgxBootrasp/app-bootstrap-module/app-bootstrap-module.component';

@NgModule({
  declarations: [
    AppComponent,
    AppBootstrapModuleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppBoostrapModuleModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
