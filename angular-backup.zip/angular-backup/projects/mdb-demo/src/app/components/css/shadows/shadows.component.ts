import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shadows',
  templateUrl: './shadows.component.html',
  styleUrls: ['./shadows.component.scss']
})
export class ShadowsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
