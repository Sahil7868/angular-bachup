import { Input, Component, OnInit } from '@angular/core';
import { CategoryService } from '../../controllers/category.service';
import { ProductService } from '../../controllers/product.service';

@Component({

  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

// https://community.algolia.com/angular-instantsearch/getting-started.html

export class HeaderComponent implements OnInit {

  grandtotal: any = Number;
  products: any = [];
  carts: any = [];
  temp: any = [];
  totalqauntity: any = Number;
  qauntityArray: any = [];
  key = 'CartId';

  @Input() siblingpro: any;

  constructor(public rest: CategoryService, public _pro: ProductService) { }



  ngOnInit() {
    this.getCategory();
    this.getCart();
  }

  getCategory() {
    this.products = [];
    this.rest.getCategory().subscribe((data: {}) => {
      // console.log(data);
      this.products = data;
    });


  }

  createRange(number) {
    this.qauntityArray = [];
    for (var i = 1; i <= number; i++) {
      this.qauntityArray.push(i);
    }
    return this.qauntityArray;
  }

  deletecart(id, name) {
    var confirmation = confirm("Are You Sure You Want To Remove " + name);
    if (confirmation == true) {


      this._pro.deleteCart(id).subscribe(() => {


        this.getCart();

        this.siblingpro.getProduct();


      });
    }
    else {
      alert("Happy Shopping");
    }

  }

  getTotalQauntity(id) {

    localStorage.setItem(this.key, id);
    //let myItem = localStorage.getItem(this.key);
    //console.log(myItem);
    this._pro.getTotalQauntity(id).subscribe((data: {}) => {
      // console.log(data);
      this.totalqauntity = data;
    });
  }

  getUpdateCart() {

    if (this.totalqauntity == 0) {
      alert("Select Appropriate Qauntity");
    }
    else {
      let myItem = localStorage.getItem(this.key);
     // console.log(myItem);
      this._pro.updateCart(myItem, this.totalqauntity).subscribe((data: {}) => {
      //  console.log(data);
        this.getCart();

        this.siblingpro.getProduct();

      });
    }

  }

  getCart() {
    this.carts = [];
    this._pro.getCart('sahilsurani7868@gmail.com').subscribe((data: {}) => {
      // console.log(data);
      this.carts = data;

    });

    this._pro.getGrandTotal('sahilsurani7868@gmail.com').subscribe((data: {}) => {
      // console.log(data);
      this.grandtotal = data;
    });

  }

}
