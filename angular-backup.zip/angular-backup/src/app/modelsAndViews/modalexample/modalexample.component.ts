import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modalexample',
  templateUrl: './modalexample.component.html',
  styleUrls: ['./modalexample.component.scss']
})
export class ModalexampleComponent implements OnInit {

  

  constructor() { }
 
  ngOnInit() {
  }

}
