import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private endpoint = 'http://192.168.100.180:8085/ShopperHolicsmaven/getallProducts/';

  private cartUrl =  'http://192.168.100.180:8085/ShopperHolicsmaven/addCart/';


  private httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

constructor(private http: HttpClient) { }

  private extractData(res: Response) {
    let body = res;
    return body || { };
  }
  
  getProduct(): Observable<any> {
    return this.http.get(this.endpoint).pipe(
      map(this.extractData));
  }

  addToCart(cart): Observable<any> {
    //console.log(cart);
    return this.http.post<any>(this.cartUrl,JSON.stringify(cart),this.httpOptions).pipe(
      tap((cart) => console.log(`added cart w/ id=${cart.cartId}`)),
      catchError(this.handleError<any>('addToCart'))
    );
  }

  addProduct(product): Observable<any> {
    //console.log(cart);
    return this.http.post<any>('http://192.168.100.180:8085/ShopperHolicsmaven/addProduct/',JSON.stringify(product),this.httpOptions).pipe(
      tap((product) => console.log(`added product w/ id=${product.pid}`)),
      catchError(this.handleError<any>('addProduct'))
    );
  }

  getCart(id): Observable<any> {
   // console.log(id);
    return this.http.get('http://192.168.100.180:8085/ShopperHolicsmaven/getCartByEmail/'+ id+'.json').pipe(
      map(this.extractData));
  }

  getGrandTotal(id): Observable<any> {
    // console.log(id);
     return this.http.get('http://192.168.100.180:8085/ShopperHolicsmaven/gettotal/'+ id+'.json').pipe(
       map(this.extractData));
   }

   getTotalQauntity(id): Observable<any> {
    // console.log(id);
     return this.http.get('http://192.168.100.180:8085/ShopperHolicsmaven/getqauntity/'+ id+'.json').pipe(
       map(this.extractData));
   }

   updateCart(id,qauntity): Observable<any> {
    // console.log(id);
     return this.http.get('http://192.168.100.180:8085/ShopperHolicsmaven/updateCart/'+ id + '/' + qauntity + '.json').pipe(
       map(this.extractData));
   }


   deleteCart (id): Observable<any> {
    return this.http.delete<any>('http://192.168.100.180:8085/ShopperHolicsmaven/deleteCart/' + id + '.json', this.httpOptions).pipe(
      tap(_ => console.log(`deleted product id=${id}`)),
      catchError(this.handleError<any>('deleteProduct'))
    );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
  
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
  
      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);
  
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
