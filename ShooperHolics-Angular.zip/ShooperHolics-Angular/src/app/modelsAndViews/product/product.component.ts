import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../controllers/product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {


  faci: number;
  cart = { pid: 0, email: 'sahilsurani7868@gmail.com', total: 0, qauntity: 0 };
  products: any = [];
  slides: any = [[]];
  qauntityArray: any = [];

  constructor(public rest: ProductService) { }

  ngOnInit() {
    this.getProduct();


  }

  public getProduct() {
    this.products = [];
    this.rest.getProduct().subscribe((data: {}) => {
      //console.log("ayuu");
      this.products = data;

    });

  }
  createRange(number) {
    this.qauntityArray = [];
    for (var i = 1; i <= number; i++) {
      this.qauntityArray.push(i);
    }
    return this.qauntityArray;
  }

  addTocart(pid, price) {
    if (this.faci == 0) {
      alert("Select appropriate Qauntity");
    }
    else {
      this.cart.pid = pid;
      this.cart.total = (this.faci * price);
      this.cart.qauntity = this.faci;
      // console.log(pid);
      //console.log(this.cart.total);
      this.rest.addToCart(this.cart).subscribe((result) => {
        //console.log(result);
        this.getProduct();
        alert("Added Successfully");
      }, (err) => {
        console.log(err);
      });


    }
  }

}

